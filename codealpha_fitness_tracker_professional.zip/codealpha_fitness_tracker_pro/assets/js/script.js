const form = document.getElementById('workoutForm');
const workoutList = document.getElementById('workoutList');
const emptyState = document.getElementById('emptyState');
const searchInput = document.getElementById('searchInput');
const clearBtn = document.getElementById('clearBtn');
const exportBtn = document.getElementById('exportBtn');
const themeToggle = document.getElementById('themeToggle');
const bmiBtn = document.getElementById('bmiBtn');

let workouts = JSON.parse(localStorage.getItem('fittrack-workouts')) || [];
let dailyGoal = Number(localStorage.getItem('fittrack-goal')) || 1000;

function saveData() {
  localStorage.setItem('fittrack-workouts', JSON.stringify(workouts));
  localStorage.setItem('fittrack-goal', dailyGoal);
}

function calculateStats() {
  const totalCalories = workouts.reduce((sum, item) => sum + Number(item.calories), 0);
  const totalMinutes = workouts.reduce((sum, item) => sum + Number(item.duration), 0);
  const bestBurn = workouts.length ? Math.max(...workouts.map(item => Number(item.calories))) : 0;
  return { totalCalories, totalMinutes, bestBurn, totalWorkouts: workouts.length };
}

function updateSummary() {
  const stats = calculateStats();
  document.getElementById('totalCalories').textContent = stats.totalCalories;
  document.getElementById('totalWorkouts').textContent = stats.totalWorkouts;
  document.getElementById('totalMinutes').textContent = stats.totalMinutes;
  document.getElementById('bestBurn').textContent = stats.bestBurn;
  document.getElementById('heroCalories').textContent = `${stats.totalCalories} kcal`;

  const percent = Math.min(Math.round((stats.totalCalories / dailyGoal) * 100), 100);
  const degree = percent * 3.6;
  document.getElementById('progressPercent').textContent = `${percent}%`;
  document.getElementById('progressCircle').style.background = `conic-gradient(var(--primary) ${degree}deg, rgba(148,163,184,.22) ${degree}deg)`;
  document.getElementById('heroProgress').style.width = `${percent}%`;
  document.getElementById('goalText').textContent = `${stats.totalCalories} / ${dailyGoal} kcal completed today.`;
}

function renderWorkouts(filter = '') {
  const filtered = workouts.filter(item =>
    item.exercise.toLowerCase().includes(filter.toLowerCase()) ||
    item.category.toLowerCase().includes(filter.toLowerCase())
  );

  workoutList.innerHTML = '';
  emptyState.style.display = filtered.length ? 'none' : 'block';

  filtered.forEach(item => {
    const li = document.createElement('li');
    li.className = 'workout-item';
    li.innerHTML = `
      <div>
        <h3>${item.exercise}</h3>
        <span class="tag">${item.category}</span>
        <p class="muted">${item.duration} min · ${item.calories} kcal · ${item.date}</p>
      </div>
      <button class="delete-btn" aria-label="Delete workout" onclick="deleteWorkout('${item.id}')">Delete</button>
    `;
    workoutList.appendChild(li);
  });
}

function deleteWorkout(id) {
  workouts = workouts.filter(item => item.id !== id);
  saveData();
  renderApp();
}

function renderApp() {
  updateSummary();
  renderWorkouts(searchInput.value);
}

form.addEventListener('submit', event => {
  event.preventDefault();

  const exercise = document.getElementById('exercise').value.trim();
  const category = document.getElementById('category').value;
  const duration = Number(document.getElementById('duration').value);
  const calories = Number(document.getElementById('calories').value);
  const goalInput = Number(document.getElementById('goal').value);

  if (!exercise || duration <= 0 || calories <= 0) {
    alert('Please enter valid workout details.');
    return;
  }

  if (goalInput >= 100) dailyGoal = goalInput;

  workouts.unshift({
    id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
    exercise,
    category,
    duration,
    calories,
    date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
  });

  saveData();
  form.reset();
  renderApp();
});

searchInput.addEventListener('input', () => renderWorkouts(searchInput.value));

clearBtn.addEventListener('click', () => {
  if (workouts.length && confirm('Clear all workout records?')) {
    workouts = [];
    saveData();
    renderApp();
  }
});

exportBtn.addEventListener('click', () => {
  if (!workouts.length) {
    alert('No workout data available to export.');
    return;
  }
  const header = 'Exercise,Category,Duration,Calories,Date\n';
  const rows = workouts.map(item => `${item.exercise},${item.category},${item.duration},${item.calories},${item.date}`).join('\n');
  const blob = new Blob([header + rows], { type: 'text/csv' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'fittrack-workouts.csv';
  link.click();
});

themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  const isDark = document.body.classList.contains('dark');
  themeToggle.textContent = isDark ? '☀️ Light' : '🌙 Dark';
  localStorage.setItem('fittrack-theme', isDark ? 'dark' : 'light');
});

bmiBtn.addEventListener('click', () => {
  const height = Number(document.getElementById('height').value) / 100;
  const weight = Number(document.getElementById('weight').value);
  const result = document.getElementById('bmiResult');

  if (!height || !weight) {
    result.textContent = 'Please enter valid height and weight.';
    return;
  }

  const bmi = (weight / (height * height)).toFixed(1);
  let category = 'Normal';
  if (bmi < 18.5) category = 'Underweight';
  else if (bmi >= 25 && bmi < 30) category = 'Overweight';
  else if (bmi >= 30) category = 'Obese';
  result.textContent = `BMI: ${bmi} · Category: ${category}`;
});

if (localStorage.getItem('fittrack-theme') === 'dark') {
  document.body.classList.add('dark');
  themeToggle.textContent = '☀️ Light';
}

renderApp();
