# FitTrack Pro - Fitness Tracker Web App

A professional and responsive Fitness Tracker web application built using **HTML, CSS, and JavaScript** for CodeAlpha project submission.

## Project Overview

FitTrack Pro helps users record workouts, track calories burned, monitor daily fitness goals, calculate BMI, and export workout history. The project uses browser LocalStorage, so workout records remain saved even after refreshing the page.

## Features

- Add workout name, category, duration, calories and daily calorie goal
- View total calories, total workout sessions, total minutes and best calorie burn
- Circular daily goal progress tracker
- Workout history with search option
- Delete single workout records
- Clear all workout records
- BMI calculator
- Dark mode and light mode
- Export workout history as CSV
- Fully responsive design for mobile, tablet and desktop
- Data persistence using LocalStorage

## Tech Stack

- HTML5
- CSS3
- JavaScript
- LocalStorage

## Folder Structure

```text
codealpha_fitness_tracker_pro/
│── index.html
│── README.md
└── assets/
    ├── css/
    │   └── style.css
    ├── js/
    │   └── script.js
    └── img/
```

## How to Run

1. Download or clone this repository.
2. Open `index.html` in any modern browser.
3. Start adding workouts and tracking progress.

## GitHub Upload Steps

```bash
git init
git add .
git commit -m "Add professional fitness tracker project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/codealpha-fitness-tracker.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## Suggested Repository Name

```text
codealpha-fitness-tracker
```

## Suggested GitHub Description

```text
A professional fitness tracker web app built with HTML, CSS and JavaScript for CodeAlpha internship project submission.
```

## Author

**Reshmitha Ganta**

## Acknowledgement

This project is created as part of the CodeAlpha internship/project submission.
