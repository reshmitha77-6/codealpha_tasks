const DAILY_GOAL = 1000;
const STORAGE_KEY = 'fittrack_pro_workouts';
const THEME_KEY = 'fittrack_pro_theme';

let workouts = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];

const workoutForm = document.getElementById('workoutForm');
const bmiForm = document.getElementById('bmiForm');
const workoutTable = document.getElementById('workoutTable');
const emptyState = document.getElementById('emptyState');
const searchInput = document.getElementById('searchInput');
const themeToggle = document.getElementById('themeToggle');

function saveWorkouts() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(workouts));
}

function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}

function getFilteredWorkouts() {
  const query = searchInput.value.trim().toLowerCase();
  return workouts.filter(item =>
    item.exercise.toLowerCase().includes(query) ||
    item.category.toLowerCase().includes(query)
  );
}

function renderWorkouts() {
  const filtered = getFilteredWorkouts();
  workoutTable.innerHTML = '';

  filtered.forEach((item) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.exercise}</td>
      <td>${item.category}</td>
      <td>${item.calories} kcal</td>
      <td>${item.duration} min</td>
      <td>${formatDate(item.date)}</td>
      <td><button class="delete-btn" onclick="deleteWorkout('${item.id}')">Delete</button></td>
    `;
    workoutTable.appendChild(row);
  });

  emptyState.style.display = filtered.length ? 'none' : 'block';
  updateStats();
}

function updateStats() {
  const totalCalories = workouts.reduce((sum, item) => sum + Number(item.calories), 0);
  const progress = Math.min((totalCalories / DAILY_GOAL) * 100, 100);

  document.getElementById('totalCalories').textContent = totalCalories;
  document.getElementById('totalWorkouts').textContent = workouts.length;
  document.getElementById('goalPercent').textContent = `${Math.round(progress)}%`;
  document.getElementById('progressFill').style.width = `${progress}%`;
}

workoutForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const exercise = document.getElementById('exercise').value.trim();
  const category = document.getElementById('category').value;
  const calories = Number(document.getElementById('calories').value);
  const duration = Number(document.getElementById('duration').value);

  if (!exercise || calories <= 0 || duration <= 0) {
    alert('Please enter valid workout details.');
    return;
  }

  workouts.unshift({
    id: crypto.randomUUID(),
    exercise,
    category,
    calories,
    duration,
    date: new Date().toISOString()
  });

  saveWorkouts();
  workoutForm.reset();
  renderWorkouts();
});

function deleteWorkout(id) {
  workouts = workouts.filter(item => item.id !== id);
  saveWorkouts();
  renderWorkouts();
}

bmiForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const heightCm = Number(document.getElementById('height').value);
  const weightKg = Number(document.getElementById('weight').value);
  const heightM = heightCm / 100;
  const bmi = weightKg / (heightM * heightM);

  let category = 'Normal';
  if (bmi < 18.5) category = 'Underweight';
  else if (bmi >= 25 && bmi < 30) category = 'Overweight';
  else if (bmi >= 30) category = 'Obese';

  document.getElementById('bmiValue').textContent = bmi.toFixed(1);
  document.getElementById('bmiCategory').textContent = category;
});

searchInput.addEventListener('input', renderWorkouts);

document.getElementById('clearBtn').addEventListener('click', () => {
  if (workouts.length === 0) return;
  const confirmClear = confirm('Are you sure you want to clear all workouts?');
  if (confirmClear) {
    workouts = [];
    saveWorkouts();
    renderWorkouts();
  }
});

document.getElementById('exportBtn').addEventListener('click', () => {
  if (workouts.length === 0) {
    alert('No workout data available to export.');
    return;
  }

  const header = 'Exercise,Category,Calories,Duration,Date\n';
  const rows = workouts.map(item =>
    `${item.exercise},${item.category},${item.calories},${item.duration},${formatDate(item.date)}`
  ).join('\n');

  const blob = new Blob([header + rows], { type: 'text/csv' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'fittrack-workouts.csv';
  link.click();
});

themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  const isDark = document.body.classList.contains('dark');
  localStorage.setItem(THEME_KEY, isDark ? 'dark' : 'light');
  themeToggle.textContent = isDark ? '☀️ Light Mode' : '🌙 Dark Mode';
});

function loadTheme() {
  const savedTheme = localStorage.getItem(THEME_KEY);
  if (savedTheme === 'dark') {
    document.body.classList.add('dark');
    themeToggle.textContent = '☀️ Light Mode';
  }
}

loadTheme();
renderWorkouts();
