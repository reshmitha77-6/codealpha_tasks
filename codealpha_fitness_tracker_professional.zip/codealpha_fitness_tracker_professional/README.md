# FitTrack Pro - Fitness Tracker

A professional and responsive Fitness Tracker web application created for the CodeAlpha internship project.

## 🚀 Features

- Add workout name, category, calories and duration
- Automatic total calories calculation
- Daily calorie goal progress bar
- Workout history table
- Search workouts by name or category
- Delete individual workout records
- Clear all saved workouts
- Export workout history as CSV
- BMI calculator
- Dark and light mode
- LocalStorage support to save data in the browser
- Fully responsive design for mobile, tablet and desktop

## 🛠️ Technologies Used

- HTML5
- CSS3
- JavaScript
- Browser LocalStorage

## 📁 Folder Structure

```text
codealpha_fitness_tracker_professional/
│── index.html
│── style.css
│── script.js
│── README.md
```

## ▶️ How to Run

1. Download or clone this repository.
2. Open `index.html` in any browser.
3. Start adding workouts and tracking progress.

## 📌 Project Purpose

This project helps users track their daily workouts, monitor calories burned, calculate BMI and store fitness activity data locally.

## 🔗 GitHub Upload Commands

```bash
git init
git add .
git commit -m "Initial commit - CodeAlpha Fitness Tracker"
git branch -M main
git remote add origin https://github.com/your-username/codealpha-fitness-tracker.git
git push -u origin main
```

## 🙋‍♀️ Author

**Reshmitha Ganta**

## 🏷️ Internship

CodeAlpha Web Development Internship Project
